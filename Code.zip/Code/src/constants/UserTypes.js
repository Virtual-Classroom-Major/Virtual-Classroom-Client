exports.STUDENT = "STUDENT";
exports.FACULTY = "FACULTY";
exports.ADMIN = "ADMIN";
